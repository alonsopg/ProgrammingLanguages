PRACTICA 09

Alvarez Takisawa Jose Luis.
Palomino Garibay Alonso.

La practica la pusimos todo en un solo archivo, al final de la practica vienen las pruebas con las que
probamos la practica.

